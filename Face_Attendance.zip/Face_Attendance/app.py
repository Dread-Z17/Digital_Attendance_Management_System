from flask import Flask, request, jsonify
from flask_cors import CORS
import face_recognition
import numpy as np
import sqlite3
import cv2
import base64
from datetime import datetime
import os

# ------------------ Flask App Setup ------------------
app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

# ------------------ Configuration ------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
KNOWN_FACES_DIR = os.path.join(DATA_DIR, "known_faces")
DB_PATH = os.path.join(DATA_DIR, "faces.db")

os.makedirs(KNOWN_FACES_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)

# ------------------ Database Initialization ------------------
def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # encoding column allows NULL (QR-only students may not have a face encoding)
    c.execute('''CREATE TABLE IF NOT EXISTS students (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_id TEXT UNIQUE NOT NULL,
                    name TEXT NOT NULL,
                    course TEXT,
                    email TEXT,
                    image_path TEXT,
                    encoding BLOB
                )''')

    c.execute('''CREATE TABLE IF NOT EXISTS attendance (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_id TEXT NOT NULL,
                    name TEXT NOT NULL,
                    time TEXT NOT NULL,
                    status TEXT NOT NULL
                )''')
    conn.commit()
    conn.close()

init_db()

# ------------------ Helpers ------------------
def decode_image(img_data):
    """
    Decode a base64 data url (data:image/...;base64,....) to OpenCV BGR image
    """
    if not isinstance(img_data, str) or ',' not in img_data:
        return None
    try:
        img_bytes = base64.b64decode(img_data.split(',')[1])
        np_img = np.frombuffer(img_bytes, np.uint8)
        img = cv2.imdecode(np_img, cv2.IMREAD_COLOR)
        return img
    except Exception:
        return None

def mark_attendance_in_db(student_id, name, status="Present"):
    time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("INSERT INTO attendance (student_id, name, time, status) VALUES (?, ?, ?, ?)",
              (student_id, name, time_str, status))
    conn.commit()
    conn.close()
    return time_str

# =============== Register face (existing) ===============
@app.route('/register', methods=['POST'])
def register_face():
    try:
        data = request.json
        student_id = data.get('student_id')
        name = data.get('name')
        img_data = data.get('image')

        if not all([student_id, name, img_data]):
            return jsonify({'status': 'error', 'message': 'Missing required fields'}), 400

        img = decode_image(img_data)
        if img is None:
            return jsonify({'status': 'error', 'message': 'Invalid image data'}), 400

        face_locations = face_recognition.face_locations(img)
        if not face_locations:
            return jsonify({'status': 'error', 'message': 'No face detected'}), 400
        if len(face_locations) > 1:
            return jsonify({'status': 'error', 'message': 'Multiple faces detected'}), 400

        encoding = face_recognition.face_encodings(img, face_locations)[0]
        file_path = os.path.join(KNOWN_FACES_DIR, f"{student_id}_{name}.jpg")
        cv2.imwrite(file_path, img)

        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        # upsert student (allow QR-only students to be updated with face)
        c.execute("SELECT student_id FROM students WHERE student_id = ?", (student_id,))
        if c.fetchone():
            c.execute("""UPDATE students SET name=?, image_path=?, encoding=?, course=COALESCE(course,''), email=COALESCE(email,'')
                         WHERE student_id=?""",
                      (name, file_path, encoding.tobytes(), student_id))
        else:
            c.execute("INSERT INTO students (student_id, name, image_path, encoding) VALUES (?, ?, ?, ?)",
                      (student_id, name, file_path, encoding.tobytes()))
        conn.commit()
        conn.close()

        return jsonify({'status': 'success', 'message': 'Face registered successfully!'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'Error registering face: {str(e)}'}), 500

# =============== Recognize face ===============
@app.route('/recognize', methods=['POST'])
def recognize_face():
    try:
        data = request.json
        img_data = data.get('image')
        if not img_data:
            return jsonify({'status': 'error', 'message': 'Missing image data'}), 400

        img = decode_image(img_data)
        if img is None:
            return jsonify({'status': 'error', 'message': 'Invalid image data'}), 400

        face_locations = face_recognition.face_locations(img)
        if not face_locations:
            return jsonify({'status': 'error', 'message': 'No face detected'}), 400
        if len(face_locations) > 1:
            return jsonify({'status': 'error', 'message': 'Multiple faces detected'}), 400

        encoding = face_recognition.face_encodings(img, face_locations)[0]

        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT student_id, name, encoding FROM students WHERE encoding IS NOT NULL")
        rows = c.fetchall()
        conn.close()

        if not rows:
            return jsonify({'status': 'error', 'message': 'No registered faces'}), 400

        known_encodings = []
        known_ids = []
        known_names = []
        for r in rows:
            try:
                known_encodings.append(np.frombuffer(r[2], dtype=np.float64))
                known_ids.append(r[0])
                known_names.append(r[1])
            except Exception:
                continue

        if not known_encodings:
            return jsonify({'status': 'error', 'message': 'No valid face encodings stored'}), 400

        face_distances = face_recognition.face_distance(known_encodings, encoding)
        best_match_index = int(np.argmin(face_distances))
        if face_distances[best_match_index] < 0.6:
            student_id = known_ids[best_match_index]
            name = known_names[best_match_index]
            time_str = mark_attendance_in_db(student_id, name, "Present")
            return jsonify({'status': 'success', 'name': name, 'student_id': student_id, 'time': time_str})
        else:
            return jsonify({'status': 'error', 'message': 'Face not recognized'}), 400
    except Exception as e:
        return jsonify({'status': 'error', 'message': f'Error recognizing face: {str(e)}'}), 500

# =============== Register student via QR form (backend) ===============
@app.route('/register_qr_student', methods=['POST'])
def register_qr_student():
    try:
        data = request.json
        student_id = (data.get('student_id') or "").strip()
        name = (data.get('name') or "").strip()
        course = (data.get('course') or "").strip()
        email = (data.get('email') or "").strip()

        if not student_id or not name:
            return jsonify({'status': 'error', 'message': 'student_id and name required'}), 400

        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT student_id FROM students WHERE student_id = ?", (student_id,))
        if c.fetchone():
            c.execute("UPDATE students SET name=?, course=?, email=? WHERE student_id=?",
                      (name, course, email, student_id))
            msg = 'Student updated'
        else:
            c.execute("INSERT INTO students (student_id, name, course, email) VALUES (?, ?, ?, ?)",
                      (student_id, name, course, email))
            msg = 'Student registered'
        conn.commit()
        conn.close()
        return jsonify({'status': 'success', 'message': msg})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# =============== Mark QR attendance ===============
@app.route('/mark_qr_attendance', methods=['POST'])
def mark_qr_attendance():
    try:
        data = request.json
        student_id = (data.get('student_id') or "").strip()
        if not student_id:
            return jsonify({'status': 'error', 'message': 'student_id required'}), 400

        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT name FROM students WHERE student_id = ?", (student_id,))
        row = c.fetchone()
        if not row:
            conn.close()
            return jsonify({'status': 'error', 'message': 'Student not registered'}), 400
        name = row[0]

        # prevent multiple marks in one day
        today = datetime.now().strftime('%Y-%m-%d')
        c.execute("SELECT COUNT(*) FROM attendance WHERE student_id=? AND date(time)=?", (student_id, today))
        already = c.fetchone()[0]
        if already:
            conn.close()
            return jsonify({'status': 'error', 'message': 'Already marked today'}), 400

        time_str = mark_attendance_in_db(student_id, name, "Present")
        return jsonify({'status': 'success', 'student_id': student_id, 'name': name, 'time': time_str})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# =============== Dashboard data ===============
@app.route('/dashboard_data', methods=['GET'])
def dashboard_data():
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT COUNT(*) FROM students")
        total_students = c.fetchone()[0]
        today = datetime.now().strftime('%Y-%m-%d')
        c.execute("SELECT COUNT(*) FROM attendance WHERE date(time)=?", (today,))
        today_attendance = c.fetchone()[0]
        c.execute("SELECT COUNT(*) FROM attendance")
        total_records = c.fetchone()[0]
        conn.close()
        rate = round((today_attendance / total_students * 100), 1) if total_students else 0.0
        return jsonify({'status': 'success', 'total_students': total_students,
                        'today_attendance': today_attendance, 'total_records': total_records,
                        'attendance_rate': rate})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# =============== Attendance records (list) ===============
@app.route('/attendance_records', methods=['GET'])
def attendance_records():
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT student_id, name, time, status FROM attendance ORDER BY time DESC")
        rows = c.fetchall()
        conn.close()
        records = [{'student_id': r[0], 'name': r[1], 'time': r[2], 'status': r[3]} for r in rows]
        return jsonify({'status': 'success', 'records': records})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# =============== Students list ===============
@app.route('/students', methods=['GET'])
def students_list():
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT student_id, name, course, email FROM students ORDER BY student_id")
        rows = c.fetchall()
        conn.close()
        students = [{'student_id': r[0], 'name': r[1], 'course': r[2] or '', 'email': r[3] or ''} for r in rows]
        return jsonify({'status': 'success', 'students': students})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# ------------------ Run ------------------
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
