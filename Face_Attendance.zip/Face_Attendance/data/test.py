import sqlite3
import os

DB_PATH = r"d:\Projects\Face_Attendance\data\faces.db"
DATA_DIR = "d:/Projects/Face_Attendance/data"

print(f"Testing database path: {DB_PATH}")
print(f"Directory exists: {os.path.exists(DATA_DIR)}")
print(f"Directory writable: {os.access(DATA_DIR, os.W_OK)}")

try:
    conn = sqlite3.connect(DB_PATH)
    print("✅ Successfully connected to database!")
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS test (id INTEGER PRIMARY KEY)")
    conn.commit()
    print("✅ Test table created successfully!")
except sqlite3.OperationalError as e:
    print(f"❌ SQLite error: {e}")
except Exception as e:
    print(f"❌ Unexpected error: {e}")
finally:
    if 'conn' in locals():
        conn.close()
        print("Database connection closed.")